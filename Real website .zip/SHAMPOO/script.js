  // JavaScript to handle header background change on scroll
  window.addEventListener('scroll', function() {
    const header = document.querySelector('header');
    if (window.scrollY > 50) {
      header.classList.add('scrolled'); // Add 'scrolled' class when scrolled more than 50px
    } else {
      header.classList.remove('scrolled'); // Remove 'scrolled' class when back at top
    }
  });